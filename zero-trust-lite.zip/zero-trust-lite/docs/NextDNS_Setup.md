# NextDNS Setup Guide for Zero Trust Lite (ZTL)

Welcome to the **NextDNS Setup Guide** for **Zero Trust Lite (ZTL)**! This guide will walk you through the process of setting up **NextDNS**, a privacy-focused DNS service, to enhance your security and protect your online activities.

---

## 🚀 **What is NextDNS?**

**NextDNS** is a privacy-first DNS service that blocks trackers, malware, and advertisements, while ensuring your online activities remain private. By using NextDNS, you can prevent tracking, enhance your privacy, and bypass content restrictions on the web.

---

## 🛠️ **Steps to Set Up NextDNS**

### Step 1: Create a NextDNS Account
1. Visit the official website: [NextDNS](https://nextdns.io/).
2. Click on **Sign Up** to create a free account.
3. Fill in your details (email and password) and complete the registration process.

---

### Step 2: Configure Your NextDNS Profile
1. Once logged in, go to your **NextDNS Dashboard**.
2. Create a new **Profile** by clicking **Add Profile**.
3. Choose a **Profile Name** (e.g., "ZTL Profile").
4. Customize your profile by selecting different **filters** (e.g., Malware Blocking, Ads Blocker, Privacy Protection) according to your needs.

---

### Step 3: Set Up DNS Servers on Your Device

#### For Android:
1. Open **Settings** > **Network & Internet** > **Wi-Fi**.
2. Tap the Wi-Fi network you are connected to.
3. Scroll down and tap **Advanced** > **Private DNS**.
4. Select **Private DNS provider hostname** and enter:
5. Save the changes.

---
#### For iOS:
1. Open **Settings** > **Wi-Fi**.
2. Tap the **i** icon next to the Wi-Fi network you are connected to.
3. Scroll down to **Configure DNS** and select **Manual**.
4. Tap **Add Server** and enter
5. Save the changes.

---
#### For Windows:
1. Open **Control Panel** > **Network and Sharing Center** > **Change adapter settings**.
2. Right-click your active network adapter and select **Properties**.
3. Click on **Internet Protocol Version 4 (TCP/IPv4)** and then **Use the following DNS server addresses**.
4. Enter the following DNS addresses:
5. Click **OK** to save the settings.

---
### Step 4: Enable Privacy & Security Features
1. In your **NextDNS Dashboard**, navigate to your **Profile** settings.
2. Enable the following features:
- **Content Filtering**: Block ads, trackers, and malicious websites.
- **DNS Over HTTPS (DoH)**: Encrypt DNS queries to ensure privacy.
- **Analytics & Logs**: Optionally enable this feature to track DNS queries, but disable it if you want to maintain maximum privacy.

---

## 🔐 **ZTL Integration with NextDNS**
- **Zero Trust Lite (ZTL)** uses **NextDNS** to ensure that all your DNS queries are private and secure. It prevents malicious websites from being accessed and blocks trackers from following your activities online.
- With **NextDNS**, your DNS traffic is encrypted using **DNS over HTTPS (DoH)**, ensuring no one can see or tamper with your browsing data.

---

## 💡 **Privacy Features**

- **Ad Blocking**: Automatically blocks intrusive ads and trackers across all apps and websites.
- **Privacy Protection**: Prevents third-party sites from collecting your personal data.
- **Parental Controls**: Optionally, block content that's not suitable for certain age groups.
- **Customizable Filters**: You can create your own blocklist to block specific content or domains.

---

## ✅ **You're All Set!**
By following this guide, you’ve successfully set up **NextDNS** to work with **Zero Trust Lite (ZTL)**, enhancing your online privacy and security. Your device is now protected from harmful domains, trackers, and unwanted ads.

---

## 📚 **Additional Resources**
- [NextDNS Official Documentation](https://nextdns.io/docs/)
- [NextDNS Privacy Policy](https://nextdns.io/privacy)
- [NextDNS GitHub Repository](https://github.com/nextdns/)

---

**Created by Amicia_Michella** | [GitHub Profile](https://github.com/devamicia)

---

