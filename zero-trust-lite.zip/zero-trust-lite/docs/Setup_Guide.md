# Zero Trust Lite (ZTL) Setup Guide

Welcome to **Zero Trust Lite (ZTL)**! This guide will walk you through the setup of a basic, but effective, privacy protection system. All the tools are easy to install and won’t require using a command-line interface (CLI). Let's get started!

---

## 🔥 **Prerequisites**

Before you dive in, here are the tools you’ll need to install from F-Droid or the Google Play Store:

- **SimpleLogin** – A service for creating anonymous email aliases.
- **NextDNS** – A DNS service that ensures your browsing activity stays private.
- **Secret Space Encryptor (SSE)** – A tool to encrypt your sensitive files.

---

## 1. **Set Up SimpleLogin for Anonymous Email**

You don’t want your real email exposed on the internet. SimpleLogin helps create email aliases for you to keep your real email address private.

### Steps:
1. Download and install **SimpleLogin** from [F-Droid](https://f-droid.org/packages/io.simplelogin.android/) or [Google Play Store](https://play.google.com/store/apps/details?id=io.simplelogin.android).
2. Create an account or sign in.
3. Once logged in, create an alias to start using for various services. Keep your real email hidden.

### Setup in ZTL:
- After creating your alias, **SimpleLogin** will auto-manage everything for you. No need for extra configurations. Just use the alias wherever you need to sign up!

---

## 2. **Set Up NextDNS for Privacy Browsing**

NextDNS helps block trackers, ads, and malicious sites, keeping your browsing activity anonymous and secure.

### Steps:
1. Download and install **NextDNS** from [F-Droid](https://f-droid.org/packages/io.nextdns.android/) or [Google Play Store](https://play.google.com/store/apps/details?id=io.nextdns.android).
2. Create an account and configure the settings for privacy (block ads, trackers, etc.).
3. Set NextDNS as your DNS provider in your device settings.

### Setup in ZTL:
- Add your unique NextDNS configuration ID to your device, following the steps from the NextDNS app. No further configuration needed for ZTL!

---

## 3. **Encrypt Your Files with Secret Space Encryptor (SSE)**

Encrypting your files ensures that any sensitive data stays safe and hidden from unauthorized access.

### Steps:
1. Download and install **Secret Space Encryptor (SSE)** from [F-Droid](https://f-droid.org/packages/com.securespaceencryptor/) or [Google Play Store](https://play.google.com/store/apps/details?id=com.securespaceencryptor).
2. Open the app and set up an encryption password.
3. Select files that you want to keep safe, and encrypt them using the app.

### Setup in ZTL:
- Your encrypted files are now safe. No additional configuration is required beyond the basic encryption setup.

---

## 4. **Final Steps & Checking Everything**

Once you’ve installed and configured the tools, double-check that everything works:

- Test your email alias by sending and receiving messages with SimpleLogin.
- Browse the web and check if NextDNS is blocking ads and trackers.
- Open and check if your encrypted files are locked and secure with Secret Space Encryptor.

---

## 📚 **Additional Resources**

- [SimpleLogin Documentation](https://simplelogin.io/docs/)
- [NextDNS Documentation](https://nextdns.io/docs/)
- [Secret Space Encryptor Documentation](https://github.com/secret-space-encryptor)

---

## 🎉 **Congrats!**

You’ve just set up **Zero Trust Lite (ZTL)** on your device. This means your online privacy is now significantly improved. You can now use the internet with much more confidence, knowing your data is safe and secure.

If you encounter any problems, you can always refer to the official documentation of each tool for troubleshooting.

---

### 😎 **Created by Amicia_Michella** | [GitHub Profile](https://github.com/devamicia)

---

**Key Notes**:
- No CLI or terminal is required. This setup is entirely app-based and straightforward.
- You are now using **Zero Trust Lite (ZTL)** to enhance your online privacy.
- Always ensure that your apps are up to date for the best security practices.

---