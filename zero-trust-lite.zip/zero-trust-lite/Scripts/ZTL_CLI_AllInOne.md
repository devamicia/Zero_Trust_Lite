
# Zero Trust Lite - Termux CLI Mode
*ZTL Secure Stack Setup via Termux on Android (No UI, Just Ops)*

**Author:** Amicia_Michella  
**Handle:** devamicia

---

## Overview
ZTL (Zero Trust Lite) via Termux enables full command-line deployment of your security stack on Android — with a minimalist approach. No root, no gimmicks, just clean ops.

---

## Requirements

- **Termux** (from F-Droid)
- **Git** (via Termux)
- **curl**, **openssl**, **tar**
- Optional:
  - Acode (for editing scripts)
  - Secret Space Encryptor (GUI tool for encryption)
  - File manager like Material Files

---

## Initial Setup

### Update Termux & Install Tools
```bash
pkg update && pkg upgrade -y
pkg install curl git tar openssl -y
```

### Grant Storage Access
```bash
termux-setup-storage
```

---

## Clone & Run Setup Script

### Clone Your Repo (Optional)
```bash
git clone https://github.com/yourusername/ztl-setup.git
cd ztl-setup/scripts
```

### Run Main Setup Script
```bash
chmod +x ztl_setup.sh
./ztl_setup.sh
```

---

## Main Setup Script: `ztl_setup.sh`

```bash
#!/bin/bash

# ZTL Setup Script - Zero Trust Lite Setup

# 1. Install SimpleLogin (placeholder for CLI-based or download method)
echo "Installing SimpleLogin..."
curl -sSL https://github.com/simple-login/app/releases/download/v2.11.0/simple-login-linux-x86_64.tar.gz -o simplelogin.tar.gz
tar -xzvf simplelogin.tar.gz
chmod +x simplelogin
mv simplelogin /usr/local/bin/
echo "SimpleLogin installed successfully."

# 2. Setup NextDNS
echo "Configuring NextDNS..."
curl -sSL https://nextdns.io/install | bash
echo "NextDNS configuration complete."

# 3. Setup Secret Space Encryptor (SSE)
echo "Setting up Secret Space Encryptor..."
# No CLI version, configure manually in GUI
echo "Encryption setup assumed via GUI (SSE Android)."

# 4. Final Message
echo "Zero Trust Lite Setup Completed."
```

---

## Custom Scripts

### Encrypt File with OpenSSL
```bash
#!/bin/bash
# encrypt_file.sh
openssl enc -aes-256-cbc -salt -in "$1" -out "$1.enc"
```

### Decrypt File
```bash
#!/bin/bash
# decrypt_file.sh
openssl enc -d -aes-256-cbc -in "$1" -out "${1%.enc}.dec"
```

---

## Example Folder Structure

```
ZTL/
├── docs/
│   └── ZTL_CLI_AllInOne.md
├── scripts/
│   ├── ztl_setup.sh
│   ├── encrypt_file.sh
│   └── decrypt_file.sh
├── config/
│   └── config.json
└── LICENSE.md
```

---

## Sample `config.json`
```json
{
  "encryptionKey": "replace_this_with_secure_key",
  "filePath": "/storage/emulated/0/Download/Encrypted",
  "encryptionMethod": "AES-256"
}
```

---

## Helpful Commands

- **Navigate to Downloads:**
```bash
cd /storage/emulated/0/Download/
```

- **List files**
```bash
ls -al
```

- **Make script executable**
```bash
chmod +x scriptname.sh
```

---

## Security Reminders

- Don't store real keys or tokens in plaintext config files.
- Use `.gitignore` to exclude sensitive stuff before pushing to GitHub.
- Keep all backups encrypted before upload/cloud sync.

---

## Status Checklist

- [x] Termux Installed  
- [x] CLI Tools Ready  
- [x] Setup Script Run  
- [ ] Encrypted Backups  
- [ ] Configured NextDNS  
- [ ] Custom Domain Emails (SimpleLogin)

---

## Final Words

Zero Trust isn’t a product — it’s a mindset.  
On Android, it’s a DIY battlefield.  
And with Termux, you’re the general.

**ZTL CLI Mode: ACTIVE.**
